package cofh.plugins.nei;

import codechicken.nei.api.API;
import codechicken.nei.api.IConfigureNEI;
import cofh.CoFHCore;

public class NEICoFHConfig implements IConfigureNEI {

	/* IConfigureNEI */
	@Override
	public void loadConfig() {

		API.registerNEIGuiHandler(NEIGuiHandler.instance);
	}

	@Override
	public String getName() {

		return CoFHCore.modName;
	}

	@Override
	public String getVersion() {

		return CoFHCore.version;
	}

}
