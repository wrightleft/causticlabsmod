package cofh.core.sided;

public interface IRunnableSided extends IRunnableClient, IRunnableServer {
}
